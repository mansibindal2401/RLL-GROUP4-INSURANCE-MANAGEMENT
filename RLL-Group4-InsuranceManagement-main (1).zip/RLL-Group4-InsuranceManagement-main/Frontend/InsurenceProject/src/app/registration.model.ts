export interface registration{
     userid:string;
    userName:string;
    password:string;
    email:string;
    mobile:string;
}
