export class updateModel {
    constructor(
      public userid:string,
       public userName:string,
       public password:string,
       public email:string,
       public mobile:string,
    ){}
}
